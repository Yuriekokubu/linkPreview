<?php session_start();
include('config.php');
   ?>
   
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.9.0/bootstrap-table.min.css'>
    <link rel='stylesheet' href='https://cdn.datatables.net/1.10.9/css/jquery.dataTables.min.css'>
    <link rel="stylesheet" href="./style.css">

    <title>Document</title>

    <style>
        * {
            color: black;
        }

        .box {
            padding: 5rem;
        }

        input {
            border: 1px solid grey;
        }
    </style>


</head>

<body>
    <div class="container-fluid box">


        
        <?php

        require_once("config.php");
        $sql = "SELECT  web_name, web_url, web_detail FROM tb_web ";
        $result = $conn->query($sql);

        $arr_users = [];

        if ($result->num_rows > 0) {
            $arr_users = $result->fetch_all(MYSQLI_ASSOC);
        }
        ?>
        <center><h1>Website Manager</h1></center>
        
        <table id="userTable" class="display bg-primary text-dark">
            <thead>
                <th>Web_id</th>
                <th>Webname</th>
                <th>WebURL</th>
                <th>Details</th>
                <th>Action</th>
            </thead>
            <tbody>
                <div><a href="insertForm.php"/><button type="button" class="btn btn-success">ADD WEBSITE DATA</button></div><br>
                <?php if (!empty($arr_users)) { ?>
                    <?php foreach ($arr_users as $user) { ?>
                        <tr>
                            <td><?php echo $user['web_id']?></td>
                            <td><?php echo $user['web_name'] ?></td>
                            <td><?php echo $user['web_url'] ?></td>
                            <td><?php echo $user['web_details'] ?></td>
                            
                            <td><a href="edit.php"a/><button type="button" class="btn btn-warning">edit</button>
                            <a href=""a/><button type="button" class="btn btn-success">view</button>
                            <a href="delete.php"a/><button type="button" class="btn btn-danger">delete</button>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>


    </div>
    <center><a href="logout.php"/><button type="button" class="btn btn-warning">LOG OUT</button><div></center>
    <br>
    <center><a href="index.php"/><button type="button" class="btn btn-primary">BACK</button><div></center>
    </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>
    <script src='https://cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js'></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#userTable').DataTable();

        });

        $('#userTable').dataTable({
            "autoWidth": false
        });
    </script>
</body>

</html>